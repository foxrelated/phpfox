# Facebook Connect :: Change Log

## Version 4.6.0

### Information

- **Release Date:** January 09, 2018
- **Best Compatibility:** phpFox 4.6.0 or higher

### Improvements

- Check compatible with phpFox core and theme Material 4.6.0.

### Changed Files

- Install.php
- Model/Service.php
- assets/autoload.css
- assets/autoload.js
- assets/autoload.less
- assets/main.less
- hooks/bundle__start.php
- hooks/user.template_controller_login_block__end.php
- hooks/user.template_controller_register_block__end.php
- phrase.json

## Version 4.5.3

### Information

- **Release Date:** September 19, 2017
- **Best Compatibility:** phpFox 4.5.3 or higher

