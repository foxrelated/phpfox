# phpFox Twemoji Awesome :: Change Log #

## Version 4.6.0 ##

### Information ###

- **Release Date:** January 09, 2018
- **Best Compatibility:** phpFox 4.6.0 or later

### Improvements

- Check compatible with phpFox core and porting apps 4.6.0

### Changed Files

- Install.php
- assets/autoload.css
- assets/autoload.js
- assets/autoload.less
- hooks/bundle__start.php

## Version 4.5.3 ##

### Information ###

- **Release Date:** September 21, 2017
- **Best Compatibility:** phpFox 4.5.3 or later
