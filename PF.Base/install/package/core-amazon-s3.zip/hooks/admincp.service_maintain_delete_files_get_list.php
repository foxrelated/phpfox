<?php
$aPluginFiles[] = 'PF.Site/Apps/core-amazon-s3/assets';


