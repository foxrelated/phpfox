<?php

$aBundleScripts[] = [
    'autoload.js' => 'app_core-quizzes',
];