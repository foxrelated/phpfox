<?php

$aBundleScripts[] = [
    'jscript/add.js' => 'app_core-newsletter',
];