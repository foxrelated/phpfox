<?php

$aBundleScripts[] = [
    'autoload.css' => 'app_core-pages',
    'autoload.js' => 'app_core-pages',
];