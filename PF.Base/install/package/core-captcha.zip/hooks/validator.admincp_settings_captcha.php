<?php

$aValidation = [
    'captcha_limit' => [
        'def'   => 'int:required',
        'min'   => '4',
        'max'   => '6',
        'title' => 'Captcha Limit value is number 4,5,6',
    ],
];