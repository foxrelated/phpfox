# RSS-Feeds :: Change Log

## Version 4.6.1

### Information

- **Release Date:**  April 12, 2018
- **Best Compatibility:** phpFox >= 4.6.0

### Bugs fixed

- Fatal Error when click on blog category.
- Some issues of app phrases.
- Site shows error when click on "Subscribe via RSS".

## Changed Files
- M	Install.php
- M	Installation/Database/Rss_Log_User.php
- M	Installation/Version/v453.php
- M	views/controller/index.html.php

## Version 4.6.0

### Information

- **Release Date:** January 09, 2018
- **Best Compatibility:** phpFox >= 4.6.0

### Improvements

- Add RSS button to the Footer menu.
- Add back button **Subscribe via RSS** in User Profile page.
- Update layout of RSS feeds listing page.