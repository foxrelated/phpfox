<?php
$aPhotos['event_default_photo'] = [
    'title' => _p('event_default_photo'),
    'value' => $flavor->default_photo('event_default_photo', true),
];