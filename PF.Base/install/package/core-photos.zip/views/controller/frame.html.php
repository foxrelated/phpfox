<?php
 
defined('PHPFOX') or exit('NO DICE!'); 
