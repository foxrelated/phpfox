<?php
$aPluginFiles[] = 'PF.Base/module/photo/';