# Material Template :: Change Log

## Version 4.6.1p1

### Information

- **Release Date:** April xx, 2018
- **Best Compatibility:** phpFox >= 4.6.1

## Fixed bugs

- Fixed profile menu is shifted to the left incase Bundle JS/CSS is enable

## Changed Files
- M	assets/autoload.css
- M less/mt_includes/snap-section.less

## Version 4.6.1

### Information

- **Release Date:** April 12, 2018
- **Best Compatibility:** phpFox >= 4.6.1

## New Features

- Allow admin can freeze header bar, main menu, sub menu, profile menu, left and right column.

## Improvements

- Support friend's actions in Browse Liked popup
- Improve layout of Account Settings page
- Update layout for Comment and Reply box.
- Update layout for Upload Profile Cover section.
- Update layout for Custom Privacy popup.

## Fixed bugs

- Toggle link works wrong in Register Form (Landing page)
- Disallow registration stop displaying image

## Changed Files
- M	README.md
- M	assets/autoload.css
- M	assets/autoload.js
- M	assets/autoload.less
- M	assets/images/sign-up-invitation.jpg
- M	assets/variables.less
- A	changelog.md
- M	component/images/color-schemes.png
- M	component/linefico.html
- M	hooks/bundle__start.php
- M	hooks/friend.service_friend_get_2.php
- M	hooks/get_module_blocks_end.php
- M	hooks/groups.block_photo_menus.php
- M	hooks/pages.block_photo_menus.php
- M	hooks/profile.service_profile_get_profile_menu.php
- M	hooks/search.component_controller_index_process_end.php
- M	hooks/template_template_getmenu_process_menu.php
- M	html/comment.block.mini.html.php
- M	html/core.block.actions-buttons.html.php
- D	html/core.block.info.html.php
- M	html/core.block.moderation.html.php
- M	html/core.block.template-menu.html.php
- M	html/core.block.template-menufooter.html.php
- M	html/core.block.template-menusub.html.php
- M	html/core.block.template-notification.html.php
- M	html/feed.block.comment.html.php
- M	html/feed.block.display.html.php
- M	html/feed.block.edit-user-status.html.php
- M	html/feed.block.link.html.php
- M	html/feed.block.tagged.html.php
- M	html/friend.block.accept.html.php
- M	html/friend.block.mutual-browse.html.php
- M	html/friend.block.request.html.php
- M	html/friend.block.search.html.php
- M	html/friend.block.suggestion.html.php
- M	html/friend.controller.profile.html.php
- M	html/layout.html
- D	html/like.block.browse.html.php
- M	html/like.block.link.html.php
- M	html/mail.controller.index.html.php
- D	html/profile.block.info.html.php
- M	html/profile.block.pic.html.php
- M	html/user.block.featured.html.php
- M	html/user.block.friendship.html.php
- M	html/user.block.register.step2.html.php
- M	html/user.block.rows_wide.html.php
- M	html/user.controller.browse.html.php
- M	html/user.controller.login.html.php
- M	html/user.controller.privacy.html.php
- M	html/user.controller.profile.html.php
- M	html/user.controller.register.html.php
- M	html/user.controller.setting.html.php
- M	less/customize.less
- M	less/mt_includes/all-request-incoming.less
- M	less/mt_includes/block-categories.less
- M	less/mt_includes/block-menu.less
- M	less/mt_includes/block.less
- M	less/mt_includes/feed.less
- M	less/mt_includes/friend.less
- M	less/mt_includes/general.less
- M	less/mt_includes/landing.less
- M	less/mt_includes/mainnav.less
- M	less/mt_includes/member.less
- M	less/mt_includes/popup.less
- M	less/mt_includes/profile.less
- M	less/mt_includes/search-filter.less
- A	less/mt_includes/snap-section.less
- M	less/mt_includes/stickybar.less
- M	less/mt_includes/structure.less
- M	less/variables.less
- M	start.php
- M	theme.json
- M	theme.png

## Version 4.6.0

### Information

- **Release Date:** January 15, 2018
- **Best Compatibility:** phpFox >= 4.6.0