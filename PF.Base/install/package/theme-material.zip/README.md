# Material Template

## App Info

- `Theme name`: Material
- `Version`: 4.6.1p1
- `Link on Store`: https://store.phpfox.com/product/2004/material-template
- `Demo site`: https://v4.phpfox.com
- `Owner`: phpFox

## What's New in 4.6.1

- Allow admin can freeze header bar, main menu, sub menu, profile menu, left and right column.
- Support friend's actions in Browse Liked popup
- Improve layout of Account Settings page
- Update layout for Comment and Reply box.
- Update layout for Upload Profile Cover section.
- Update layout for Custom Privacy popup.

## Installation Guide

Please follow below steps to install the app:

1. Install the **Material** theme from the store.

2. Clear cache on your site.

Congratulation! You have completed the installation process.