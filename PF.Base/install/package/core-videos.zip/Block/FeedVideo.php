<?php

namespace Apps\PHPfox_Videos\Block;

use Phpfox_Component;

class FeedVideo extends Phpfox_Component
{
    public function process()
    {
    }
}
