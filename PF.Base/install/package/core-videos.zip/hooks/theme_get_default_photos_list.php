<?php
$aPhotos['video_default_photo'] = [
    'title' => _p('video_default_photo'),
    'value' => $flavor->default_photo('video_default_photo', true),
];
