<?php

$aBundleScripts[] = [
    'autoload.css' => 'app_core-music',
    'autoload.js' => 'app_core-music',
];