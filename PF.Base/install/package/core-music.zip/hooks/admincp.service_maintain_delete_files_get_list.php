<?php
$aPluginFiles[] = 'PF.Base/module/music/';