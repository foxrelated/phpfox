<?php
$aPluginFiles[] = 'PF.Base/module/poll/';