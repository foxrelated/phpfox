<?php

$aBundleScripts[] = [
    'autoload.css' => 'app_core-restful-api',
    'autoload.js' => 'app_core-restful-api',
];