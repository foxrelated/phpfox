# RESTful API

## App Info

- `App name`: RESTful API
- `Version`: 4.1.3
- `Link on Store`: https://store.phpfox.com/product/1664/restapi
- `Owner`: phpFox

## Installation Guide

Please follow below steps to install RESTful API app:

1. Install the RESTful API app from the store.

2. Clear cache on your site

Congratulation! You have completed installation process.