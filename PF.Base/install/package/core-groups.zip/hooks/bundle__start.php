<?php

$aBundleScripts[] = [
    'autoload.js' => 'app_core-groups',
    'autoload.css' => 'app_core-groups',
];